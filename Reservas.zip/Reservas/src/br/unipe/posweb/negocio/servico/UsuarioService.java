package br.unipe.posweb.negocio.servico;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import br.unipe.posweb.integracao.dao.UsuarioDAO;
import br.unipe.posweb.integracao.modelo.Usuario;

public class UsuarioService {

	private UsuarioDAO dao = new UsuarioDAO();

	/**
	 * Metodo utilizado para incluir usuario no sistema
	 * 
	 * @param usuario
	 * @throws SQLException 
	 */
		
	public void incluir(Usuario u) throws SQLException {
		
		dao.incluir(u);
					
	}

	public void gravar_edicao(Usuario u) throws SQLException, IOException {
		
		dao.gravar_edicao(u);
		
	}

	public void remover(int id) {
		
		dao.remover(id);

	}
	
	public List<Usuario> buscar(String nome) throws SQLException {
		List<Usuario> lista = dao.buscarPorNome(nome);
	    return lista;

	}
	
	public List<Usuario> logar(String email, String senha) throws SQLException {
		List<Usuario> lista = dao.logar(email, senha);
	    return lista;

	}
	

	public List<Usuario> listar() throws SQLException {
	
	    List<Usuario> lista = dao.listar();
	    return lista;
		
		
	}

}
