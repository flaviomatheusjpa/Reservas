package br.unipe.posweb.negocio.servico;

import java.sql.SQLException;
import java.util.List;
import br.unipe.posweb.integracao.dao.ReservaDAO;
import br.unipe.posweb.integracao.modelo.Reserva;

public class ReservaService {

	private ReservaDAO dao = new ReservaDAO();

	public void incluir(Reserva res) throws SQLException {
		
		dao.incluir(res);
					
	}

	public List<Reserva> listar() throws SQLException {
	
	    List<Reserva> lista = dao.listar();
	    return lista;
		
		
	}

}
