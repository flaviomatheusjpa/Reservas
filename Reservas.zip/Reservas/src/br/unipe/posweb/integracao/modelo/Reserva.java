package br.unipe.posweb.integracao.modelo;

public class Reserva {

	private int id;
	private String fileira ;
	private String poltrona;
	private String reserva;
		
	
	public void setId(int id) {
		this.id = id;		
	}
	
	public int getId() {
		return id;
	}
		
	public String getFileira() {
		return fileira;
	}
	public void setFileira(String fileira) {
		this.fileira = fileira;
	}
	public String getPoltrona() {
		return poltrona;
	}
	public void setPoltrona(String poltrona) {
		this.poltrona = poltrona;
	}
	public String getReserva() {
		return reserva;
	}
	public void setReserva(String reserva) {
		this.reserva = reserva;
	}
	
	
//	//Permite compara��o entre objetos
//	@Override
//    public boolean equals(Object obj) {
//        //se nao forem objetos da mesma classe sao objetos diferentes
//        if(!(obj instanceof Reserva)) return false; 
//
//        //se forem o mesmo objeto, retorna true
//        if(obj == this) return true;
//
//        // aqui o cast � seguro por causa do teste feito acima
//        Reserva reserva = (Reserva) obj; 
//
//        //aqui voc� compara a seu gosto, o ideal � comparar atributo por atributo
//        return this.fileira == reserva.getFileira() && this.poltrona == reserva.getPoltrona() && this.reserva == reserva.getReserva();
//    }   

	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
