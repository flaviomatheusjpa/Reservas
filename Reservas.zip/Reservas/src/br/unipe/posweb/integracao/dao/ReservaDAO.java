package br.unipe.posweb.integracao.dao;
import java.util.ArrayList;
import java.util.List;
import br.unipe.posweb.integracao.modelo.Reserva;


public class ReservaDAO {

	public void incluir(Reserva res) {
		
		System.out.println("chegou no DAO de incluir reserva");
		System.out.println(res.getFileira());
		System.out.println(res.getPoltrona());
		System.out.println(res.getReserva());
		
		//Implementar Inclus�o em Arraylist na Sess�o
		
	}
	
	public List<Reserva> listar() {
		//Concluir implementa��o
		
		Reserva res = new Reserva();
		List<Reserva> lista = new ArrayList<>();
		
		return lista;
				
	}
				
	
}
