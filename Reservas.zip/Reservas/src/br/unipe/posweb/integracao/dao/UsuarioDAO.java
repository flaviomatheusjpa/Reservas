package br.unipe.posweb.integracao.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import br.unipe.posweb.integracao.modelo.Usuario;
import br.unipe.posweb.util.ConexaoUtil;

public class UsuarioDAO {
	
	
	public void incluir(Usuario u) throws SQLException {
		
		
		try {
		
		String sql_incluir = "INSERT INTO tb_usuarios (nome, login, email, senha) VALUES (?,?,?,?)"; 
		Connection conexao = ConexaoUtil.obterConexao();
		java.sql.PreparedStatement pstm = conexao.prepareStatement(sql_incluir);
		
			pstm.setString(1, u.getNome());
			pstm.setString(2, u.getLogin());
			pstm.setString(3, u.getEmail());
			pstm.setString(4, u.getSenha());
			
		    pstm.execute();
		    
			pstm.close();		
			conexao.close();	
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
			
	}
	
	
	
	
	public Usuario findbyid(int idInt) {
			
		try {
			
			String sql_findbyid = "SELECT * FROM tb_usuarios WHERE id = ?"; 
			Connection conexao = ConexaoUtil.obterConexao();
			java.sql.PreparedStatement pstm = conexao.prepareStatement(sql_findbyid);
			
			pstm.setInt(1, idInt);
			ResultSet rs = pstm.executeQuery();

			while (rs.next()) {
				Usuario u = new Usuario();
				u.setId(Integer.parseInt(rs.getString("id")));
				u.setNome(rs.getString("nome"));
				u.setLogin(rs.getString("login"));
				u.setEmail(rs.getString("email"));
				u.setSenha(rs.getString("senha"));
				return u;
			}
			pstm.close();
			conexao.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}
	
	public Usuario findbymail(String email) {
		
		try {
			
			String sql_findbyemail = "SELECT * FROM tb_usuarios WHERE email = ?"; 
			Connection conexao = ConexaoUtil.obterConexao();
			java.sql.PreparedStatement pstm = conexao.prepareStatement(sql_findbyemail);
			
			pstm.setString(1, email);
			ResultSet rs = pstm.executeQuery();

			while (rs.next()) {
				Usuario u = new Usuario();
				u.setId(Integer.parseInt(rs.getString("id")));
				u.setNome(rs.getString("nome"));
				u.setLogin(rs.getString("login"));
				u.setEmail(rs.getString("email"));
				u.setSenha(rs.getString("senha"));
				return u;
			}
			pstm.close();
			conexao.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}
	
		
	public List<Usuario> buscarPorNome(String nome) throws SQLException {
		
		String sql_buscarpornome = "SELECT * FROM tb_usuarios WHERE nome LIKE '%"+nome+"%'";
		Connection conexao = ConexaoUtil.obterConexao();
		Usuario u = new Usuario();
		List<Usuario> lista = new ArrayList<>();
		Statement st = conexao.createStatement();
		ResultSet rs = st.executeQuery(sql_buscarpornome);
		
		
		while(rs.next()) {
			
			u = new Usuario();
			int id = rs.getInt("id");
			String name = rs.getString("nome");
			String login = rs.getString("login");
			String email = rs.getString("email");
			String senha = rs.getString("senha");
			
			u.setId(id);
			u.setNome(name);
			u.setLogin(login);
			u.setEmail(email);
			u.setSenha(senha);
			
			lista.add(u);
						
		}
			
		return lista;
			
	}	

	public List<Usuario> listar() throws SQLException {
		
		String sql_listar = "SELECT * FROM tb_usuarios";
		Connection conexao = ConexaoUtil.obterConexao();
		Usuario u = new Usuario();
		List<Usuario> lista = new ArrayList<>();
		Statement st = conexao.createStatement();
		ResultSet rs = st.executeQuery(sql_listar);
		
		while(rs.next()) {
			
			u = new Usuario();
			int id = rs.getInt("id");
			String nome = rs.getString("nome");
			String login = rs.getString("login");
			String email = rs.getString("email");
			String senha = rs.getString("senha");
			
						
			u.setId(id);
			u.setNome(nome);
			u.setLogin(login);
			u.setEmail(email);
			u.setSenha(senha);
			
			lista.add(u);		
			
		}
		
		return lista;
				
	}
	
	public void gravar_edicao(Usuario u) throws SQLException, IOException {
		
		try {
			
			String sql_editar = "UPDATE tb_usuarios SET nome = ?,login = ?, email = ?, senha = ? where id = ?";
			Connection conexao = ConexaoUtil.obterConexao();
			java.sql.PreparedStatement pstm = conexao.prepareStatement(sql_editar);
			
			pstm.setString(1, u.getNome());
			pstm.setString(2, u.getLogin());
			pstm.setString(3, u.getEmail());
			pstm.setString(4, u.getSenha());
			pstm.setInt(5, u.getId());
			
			pstm.executeUpdate();
	
			pstm.close();
			conexao.close();
						
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		
	}

	
	public void remover(int id) {
		
		try {
			
			
			String sql_remover = "DELETE FROM tb_usuarios WHERE id=?";
			Connection conexao = ConexaoUtil.obterConexao();
			java.sql.PreparedStatement pstm = conexao.prepareStatement(sql_remover);
			
			pstm.setInt(1, id);
			pstm.execute();
			pstm.close();
			pstm.close();
			
			

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	
	public List<Usuario> logar(String email, String senha) throws SQLException {
		
		String sql_autenticar = "SELECT * FROM tb_usuarios WHERE email = '"+email+"' AND senha = '"+senha+"'";
		Connection conexao = ConexaoUtil.obterConexao();
		Usuario u = new Usuario();
		List<Usuario> lista = new ArrayList<>();
		Statement st = conexao.createStatement();
		ResultSet rs = st.executeQuery(sql_autenticar);
		
		
		while(rs.next()) {
			
			u = new Usuario();
			int id = rs.getInt("id");
			String nome = rs.getString("nome");
			String login = rs.getString("login");
			String mail = rs.getString("email");
			String pass = rs.getString("senha");
			
			u.setId(id);
			u.setNome(nome);
			u.setLogin(login);
			u.setEmail(mail);
			u.setSenha(pass);
			
			lista.add(u);
						
		}
			
		return lista;
			
	}
	
	
	
	
	
	
	
	
}
