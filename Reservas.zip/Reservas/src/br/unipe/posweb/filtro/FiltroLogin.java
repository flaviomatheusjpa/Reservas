package br.unipe.posweb.filtro;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

import br.unipe.posweb.integracao.modelo.*;

@WebFilter({"/Reservas/UsuarioServlet", "/Reservas/paginas/reserva/reservas.jsp"})
public class FiltroLogin implements Filter {

    public FiltroLogin() {
        
    }

	public void destroy() {
		
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		
		HttpServletRequest req = (HttpServletRequest) request;
		Usuario u = (Usuario) req.getSession().getAttribute("usuario");
				
		//Urls e p�ginas Permitidas pelo Filtro
		
		String a = "/Reservas/";
		String b = "Logar";
		String c = "CadastroServlet";
		String d = "cadastraUsuario.jsp";
		String e = "index.jsp";
		String f = "encerra.jsp";
		String g = "bootstrap";
		String h = "img";
								
		if (u == null && !req.getRequestURI().equals(a) &&
				         !req.getRequestURI().contains(b) &&
				         !req.getRequestURI().contains(c) &&
				         !req.getRequestURI().contains(d) &&
				         !req.getRequestURI().contains(e) &&
				         !req.getRequestURI().contains(f) &&
				         !req.getRequestURI().contains(g) &&
				         !req.getRequestURI().contains(h)) {

		//	System.out.println(req.getRequestURI().toString());
		//	System.out.println("n�o passou");
			req.getSession().invalidate();
			request.setAttribute("msg", "Voc� precisa estar logado para acessar esta �rea!");
			req.getRequestDispatcher("/paginas/usuario/loginForm.jsp").forward(request, response);
					    
		} else { // Deixa passar a requisi��o
			
		//	System.out.println("passou");
			chain.doFilter(req, response);
			
		}
	}

	public void init(FilterConfig fConfig) throws ServletException {

	}

}
