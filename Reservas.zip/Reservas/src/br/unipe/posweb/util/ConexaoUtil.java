package br.unipe.posweb.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoUtil {
	
	private static String url = "jdbc:mysql://localhost/agencia";
	private static String usuario = "root";
	private static String senha = "";
	
	public static Connection obterConexao() {
		// procura a classe nas bibliotecas:
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conexao = DriverManager.getConnection(url, usuario, senha);
			return conexao;
		}
		
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Driver n�o Encontrado");
			e.printStackTrace();
		}
		
		catch (SQLException e2) {
			// TODO Auto-generated catch block
			System.out.println("Usu�rio ou Senha inv�lido(s)");
			e2.printStackTrace();
		}
	
	return null;
	
	}

}
