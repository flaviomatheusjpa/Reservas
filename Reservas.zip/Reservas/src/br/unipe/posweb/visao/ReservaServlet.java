package br.unipe.posweb.visao;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sun.org.apache.bcel.internal.generic.NEWARRAY;

import br.unipe.posweb.integracao.modelo.Reserva;


@WebServlet("/ReservaServlet")
public class ReservaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ReservaServlet() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String acao = request.getParameter("acao");
		if(acao.equalsIgnoreCase("reservar")) {
			
			try {
				reservar(request, response); // Chama o m�todo para incluir a reserva na lista e incluir a lista atualizada na sess�o.
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
						
		}
	}

	public void reservar(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
		
		HttpSession session = request.getSession();
		
		
		if (session.getAttribute("listareserva") == null) {
			
			ArrayList<String> listareserva = new ArrayList<String>();
			ArrayList<Reserva> listareservaobj = new ArrayList<Reserva>();
		
			Reserva res = new Reserva();
			
			String fileira = request.getParameter("fileira");
			String poltrona = request.getParameter("poltrona");
			String reserva = fileira.concat(poltrona);
			
			res.setFileira(fileira);
			res.setPoltrona(poltrona);
			res.setReserva(reserva);
	        
			listareserva.add(reserva); //Lista com Strings das Reservas
			listareservaobj.add(res); //Lista com Objetos das Reservas
			
			//Adiciona Listas na Sess�o
			session.setAttribute("listareserva", listareserva);
			session.setAttribute("listareservaobj", listareservaobj);
			
			PrintWriter out = response.getWriter();
				
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Assento "+reserva+ " Reservado com Sucesso');");
			out.println("location='/Reservas/paginas/reserva/reservas.jsp';");
			out.println("</script>");
										
		} else {
			
			ArrayList<Reserva> listareservaobj = (ArrayList<Reserva>) session.getAttribute("listareservaobj");
			ArrayList<String> listareserva = (ArrayList<String>) session.getAttribute("listareserva");
			Reserva res = new Reserva();
			
			String fileira = request.getParameter("fileira");
			String poltrona = request.getParameter("poltrona");
			String reserva = fileira.concat(poltrona);
			
			res.setFileira(fileira);
			res.setPoltrona(poltrona);
			res.setReserva(reserva);
	        
			//Verifica se a lista j� possui objeto igual:
			
			if (listareserva.contains(reserva)) {
				
				PrintWriter out = response.getWriter();
				
				out.println("<script type=\"text/javascript\">");
				out.println("alert('O Assento " +reserva+ " j� est� Reservado. Escolha Outro.');");
				out.println("location='/Reservas/paginas/reserva/reservas.jsp';");
				out.println("</script>");
			
			
			} else {
								
				//Adiciona Reserva na Lista
				
				listareserva.add(reserva);
				listareservaobj.add(res);				
			
				//Adiciona Lista na Sess�o
				session.setAttribute("listareservaobj", listareservaobj);
				session.setAttribute("listareserva", listareserva);
				
				PrintWriter out = response.getWriter();
			
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Assento "+reserva+ " Reservado com Sucesso');");
				out.println("location='/Reservas/paginas/reserva/reservas.jsp';");
				out.println("</script>");
							
			}
			
		}
		
	}

}
