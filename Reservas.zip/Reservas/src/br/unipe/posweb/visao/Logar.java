package br.unipe.posweb.visao;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import br.unipe.posweb.integracao.dao.UsuarioDAO;
import br.unipe.posweb.integracao.modelo.Usuario;

@WebServlet("/Logar")
public class Logar extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public Logar() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String acao = request.getParameter("acao");
			
		if (acao.equalsIgnoreCase("login")) {
			
			UsuarioDAO u = new UsuarioDAO();
			String mail = request.getParameter("email");
			String pass = request.getParameter("senha");
			Usuario user = u.findbymail(mail);
									
			if (user!=null  && user.getEmail().equals(mail) && user.getSenha().equals(pass)) {
				
				PrintWriter out = response.getWriter();
				
				request.getSession().setAttribute("usuario", user);
				response.sendRedirect("index.jsp");
				
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Usu�rio logado com sucesso!');");
				out.println("</script>");
									
			}  else {
				
				request.setAttribute("msg", "Usu�rio ou Senha incorretos!");
			    //response.sendRedirect("/Reservas/paginas/usuario/loginForm.jsp");
				request.getRequestDispatcher("/paginas/usuario/loginForm.jsp").forward(request, response);
			}

		} else {
			
			PrintWriter out = response.getWriter();
   		
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Opera��o desconhecida');");
			out.println("location='http://localhost:8080/Reservas/index.jsp';");
			out.println("</script>");
			
		}

	}

		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
