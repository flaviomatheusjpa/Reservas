package br.unipe.posweb.visao;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.unipe.posweb.integracao.dao.UsuarioDAO;
import br.unipe.posweb.integracao.modelo.Usuario;
import br.unipe.posweb.negocio.servico.UsuarioService;


/**
 * Servlet implementation class UsuarioServlet
 */
@WebServlet("/UsuarioServlet")
public class UsuarioServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private UsuarioService usuarioService = new UsuarioService();   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UsuarioServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String acao = request.getParameter("acao");
			
		if(acao.equalsIgnoreCase("incluir")) {
			try {
				salvar(request, response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (acao.equalsIgnoreCase("listar")) {
			List<Usuario> lista = null;
			try {
				lista = usuarioService.listar();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			request.setAttribute("lista", lista);
			RequestDispatcher rd = request.getRequestDispatcher("/paginas/usuario/listaUsuario.jsp");
			rd.forward(request, response);
		} else if (acao.equalsIgnoreCase("editar_usuario")) {
			try {
				editar_usuario(request , response);
								
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (acao.equalsIgnoreCase("gravar_edicao")){
			Usuario u = new Usuario();
			int id = Integer.parseInt(request.getParameter("id"));
			String nome = request.getParameter("nome");
			String login = request.getParameter("login");
			String email = request.getParameter("email");
			String senha = request.getParameter("senha");
			
			u.setId(id);
			u.setNome(nome);
			u.setLogin(login);
			u.setEmail(email);
			u.setSenha(senha);
							
			try {
				usuarioService.gravar_edicao(u);
				PrintWriter out = response.getWriter();
		    		
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Usuario Alterado com Sucesso');");
				out.println("location='/Reservas/UsuarioServlet?acao=listar';");
				out.println("</script>");
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} else if (acao.equalsIgnoreCase("deletar")){
			
				int id = Integer.parseInt(request.getParameter("id"));
				usuarioService.remover(id);
				
				PrintWriter out = response.getWriter();
	    		
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Usuario Exclu�do com Sucesso');");
				out.println("location='/Reservas/UsuarioServlet?acao=listar';");
				out.println("</script>");
	
		} else if (acao.equalsIgnoreCase("buscarUsuario")) {
			
			String nome = request.getParameter("nome");
						
			List<Usuario> lista = null;
			try {
				lista = usuarioService.buscar(nome);
				request.setAttribute("lista", lista);
				RequestDispatcher rd = request.getRequestDispatcher("/paginas/usuario/buscaPorNome.jsp");
				rd.forward(request, response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
					
			
		} else {
			
			PrintWriter out = response.getWriter();
   		
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Opera��o desconhecida');");
			out.println("location='/Reservas/index.jsp';");
			out.println("</script>");
			
		}

	}

	
	public void salvar(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
		Usuario u = new Usuario();
		String nome = request.getParameter("nome");
		String login = request.getParameter("login");
		String email = request.getParameter("email");
		String senha = request.getParameter("senha");
		
		u.setNome(nome);
		u.setLogin(login);
		u.setEmail(email);
		u.setSenha(senha);
						
		usuarioService.incluir(u);
			
		PrintWriter out = response.getWriter();
		
		out.println("<script type=\"text/javascript\">");
		out.println("alert('Usuario Inclu�do com Sucesso');");
		out.println("location='/Reservas/paginas/usuario/cadastraUsuario.jsp';");
		out.println("</script>");
		
	}

	public void editar_usuario(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
			
		int idInt = Integer.parseInt(request.getParameter("id"));
		UsuarioDAO dao = new UsuarioDAO();
		Usuario user = dao.findbyid(idInt);
		
		request.setAttribute("usuario", user);
		request.getRequestDispatcher("paginas/usuario/editaUsuario.jsp").forward(request, response);
			
	}
	
			
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
