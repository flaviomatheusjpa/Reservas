package br.unipe.posweb.visao;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import br.unipe.posweb.integracao.modelo.Usuario;
import br.unipe.posweb.negocio.servico.UsuarioService;


@WebServlet("/CadastroServlet")
public class CadastroServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private UsuarioService usuarioService = new UsuarioService();   
   
    public CadastroServlet() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
		String acao = request.getParameter("acao");
			
		if(acao.equalsIgnoreCase("incluir")) {
			try {
				salvar(request, response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	
	public void salvar(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
		
		Usuario u = new Usuario();
		String nome = request.getParameter("nome");
		String login = request.getParameter("login");
		String email = request.getParameter("email");
		String senha = request.getParameter("senha");
		
		u.setNome(nome);
		u.setLogin(login);
		u.setEmail(email);
		u.setSenha(senha);
						
		usuarioService.incluir(u);
			
		PrintWriter out = response.getWriter();
		
		out.println("<script type=\"text/javascript\">");
		out.println("alert('Usuario Inclu�do com Sucesso');");
		out.println("location='/Reservas/index.jsp';");
		out.println("</script>");
		
	}

}
